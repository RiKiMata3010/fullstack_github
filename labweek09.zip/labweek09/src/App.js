import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Welcome to Fullstack Development - I 
        </p>
        <p>
          React JS Programming Week09 Lab exercise
        </p>
        <p>
          Student ID - 101336759
        </p>
        <p>
          Name - Phoenix Armand Ani
        </p>
        <p>
          George Brown College, Toronto
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
